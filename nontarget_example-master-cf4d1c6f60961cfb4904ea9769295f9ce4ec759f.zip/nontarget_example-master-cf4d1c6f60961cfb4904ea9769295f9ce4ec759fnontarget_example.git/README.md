## Docker Image

**registry.cn-shanghai.aliyuncs.com/aliseccompetition/tensorflow:1.1.0-devel-gpu** 

- python2.7 
- cuda8.0
- tensorflow:1.1.0